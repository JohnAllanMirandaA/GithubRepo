package com.dk.jobby.jobpost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobpostApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobpostApplication.class, args);
	}

}