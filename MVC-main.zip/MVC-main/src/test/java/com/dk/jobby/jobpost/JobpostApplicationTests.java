package com.dk.jobby.jobpost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobpostApplicationTests {

	@Test
	void contextLoads() {
	}

}
